import 'package:flutter/material.dart';

class ModelSocio {
  String nombre;
  String apellidos;
  String email;

  ModelSocio({this.nombre, this.apellidos, this.email});
}
